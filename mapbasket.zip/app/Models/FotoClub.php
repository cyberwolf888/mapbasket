<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FotoClub extends Model
{
    protected $table = "foto_club";
}
