<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FotoLapangan extends Model
{
    protected $table = "foto_lapangan";
}
