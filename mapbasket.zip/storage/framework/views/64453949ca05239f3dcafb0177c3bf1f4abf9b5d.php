<!-- Widgets -->
<div class="col-lg-4 col-md-4">
		<div class="sidebar right">

			<!-- Widget -->
			<div class="widget">
				<h3 class="margin-top-0 margin-bottom-25">Search</h3>
				<form action="<?php echo e(route('home')); ?>" method="GET">
				<div class="search-blog-input">
					<div class="input">
						<input class="search-field" type="text" placeholder="Type and hit enter" value="" name="q" required/>
					</div>
				</div>
				</form>
				<div class="clearfix"></div>
			</div>
			<!-- Widget / End -->


			<!-- Widget -->
			<div class="widget margin-top-40">

				<h3>Lapangan Populer</h3>
				<ul class="widget-tabs">
                    <?php
                        $lap_populer = App\Models\Lapangan::where('status',1)->limit(5)->get()->sortByDesc('rating');
                    ?>

                    <?php $__currentLoopData = $lap_populer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="widget-content">
                                    <div class="widget-thumb">
                                    <a href="<?php echo e(route('detail.lapangan', $lap->id)); ?>"><img src="<?php echo e($lap->thumb_img); ?>" alt=""></a>
                                </div>
                                
                                <div class="widget-text">
                                    <h5><a href="pages-blog-post.html"> <?php echo e($lap->nama); ?> </a></h5>
                                    <div class="star-rating" data-rating="<?php echo e($lap->rating); ?>">
                                        <div class="rating-counter">(<?php echo e($lap->review()->where('status',1)->count()); ?> reviews)</div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</ul>

			</div>
			<!-- Widget / End-->


			<div class="clearfix"></div>
			<div class="margin-bottom-40"></div>
		</div>
	</div>