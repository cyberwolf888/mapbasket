<?php $__env->startPush('plugin_css'); ?>
    <link href="<?php echo e(url('assets/master')); ?>/lib/datatables/jquery.dataTables.css" rel="stylesheet">
    <link href="<?php echo e(url('assets/master')); ?>/lib/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('master.dashboard')); ?>">Master</a>
        <span class="breadcrumb-item active">Schedule</span>
        </nav>
    </div><!-- br-pageheader -->

    <div class="br-pagetitle">
        <i class="icon icon ion-ios-book-outline"></i>
        <div>
        <h4>Schedule</h4>
        <p class="mg-b-0">Manage data Schedule.</p>
        </div>
    </div><!-- d-flex -->

    <div class="br-pagebody">

        <div class="br-section-wrapper">
            

            <div class="table-wrapper">
                    <table id="datatable1" class="table display responsive nowrap">
                            <thead>
                              <tr>
                                <th class="wd-5p">No</th>
                                <th class="wd-20p">Club</th>
                                <th class="wd-25p">Lapangan</th>
                                <th class="wd-25p">Schedule</th>
                                <th class="wd-15p">Status</th>
                                <th class="wd-10p">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $no = 1; ?>
                              <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php echo e($item->table_color); ?>">
                                  <td><?php echo e($no); ?></td>
                                  <td><?php echo e($item->club->nama); ?></td>
                                  <td><?php echo e($item->lapangan->nama); ?></td>
                                  <td><?php echo e(date('d F Y', strtotime($item->tgl))); ?>, <?php echo e(date('H:i', strtotime($item->start))); ?> - <?php echo e(date('H:i', strtotime($item->end))); ?></td>
                                  <td><?php echo e($item->status_text); ?></td>
                                  <td>
                                      <?php if($item->status == App\Models\Schedule::VERIFICATION): ?>
                                      <a href="javascript:void(0);" onclick="approve(<?php echo e($item->id); ?>)" class="btn btn-success btn-icon"><div><i class="fa fa-check"></i></div></a>
                                      <a href="javascript:void(0);" onclick="reject(<?php echo e($item->id); ?>)" class="btn btn-danger btn-icon"><div><i class="fa fa-times"></i></div></a>
                                      <?php endif; ?>
                                  </td>
                                  <?php $no++; ?>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
            </div>
        </div>

    </div><!-- br-pagebody -->

     <!-- BASIC MODAL -->
     <div id="modaldemo1" class="modal fade">
        
        <div class="modal-dialog modal-dialog-vertical-center" role="document">
          <div class="modal-content bd-0 tx-14">
            <div class="modal-header pd-y-20 pd-x-25">
              <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Message Preview</h6>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php echo Form::open(['method' => 'post', 'id'=>'form_verification']); ?>

            <input type="hidden" name="id" value="" id="schedule_id">
            <div class="modal-body pd-25">
              <h4 class="lh-3 mg-b-20" ><a href="#" class="tx-inverse hover-primary" id="title_modal"></a></h4>
              <p class="mg-b-5">Please fill this from bellow if you need extra information. </p>
              <div class="row mg-b-25">
                <div class="col-lg-12">
                    <div class="form-group mg-b-10-force">
                        <?php echo Form::textarea('keterangan', null,['id'=>'keterangan','class'=>'form-control','rows'=>'5']); ?>

                    </div>
                </div><!-- col-12 -->
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium">Save changes</button>
              <button type="button" class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium" data-dismiss="modal">Close</button>
            </div>
            <?php echo Form::close(); ?>

          </div>
        </div><!-- modal-dialog -->
      </div><!-- modal -->

      <?php if(Session::has('message')): ?>
      <!-- BASIC MODAL -->
      <div id="modal_force_approve" class="modal fade">
          
          <div class="modal-dialog modal-dialog-vertical-center" role="document">
            <div class="modal-content bd-0 tx-14">
              <div class="modal-header pd-y-20 pd-x-25">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Message Preview</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <?php echo Form::open(['method' => 'post', 'route' => 'master.schedule.force_approve' ]); ?>

              <input type="hidden" name="id" value="<?php echo e(Session::get('id')); ?>" id="schedule_id">
              <div class="modal-body pd-25">
                <h4 class="lh-3 mg-b-20" ><a href="#" class="tx-inverse hover-primary"><?php echo e(Session::get('message')); ?></a></h4>
                <p class="mg-b-5">Please fill this from bellow if you need extra information. </p>
                <div class="row mg-b-25">
                  <div class="col-lg-12">
                      <div class="form-group mg-b-10-force">
                          <?php echo Form::textarea('keterangan', null,['id'=>'keterangan','class'=>'form-control','rows'=>'5']); ?>

                      </div>
                  </div><!-- col-12 -->
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium">Save changes</button>
                <button type="button" class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium" data-dismiss="modal">Close</button>
              </div>
              <?php echo Form::close(); ?>

            </div>
          </div><!-- modal-dialog -->
        </div><!-- modal -->

      <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>
    <script src="<?php echo e(url('assets/master')); ?>/lib/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo e(url('assets/master')); ?>/lib/datatables-responsive/dataTables.responsive.js"></script>
    <script src="<?php echo e(url('assets/master')); ?>/lib/select2/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function(){
      'use strict';

      $('#datatable1').DataTable({
        responsive: true,
        language: {
          searchPlaceholder: 'Search...',
          sSearch: '',
          lengthMenu: '_MENU_ items/page',
        }
      });

      // Select2
      $('.dataTables_length select').select2({ minimumResultsForSearch: Infinity });
      
      <?php if(Session::has('message')): ?>
      $('#modal_force_approve').modal('show'); 
      <?php endif; ?>
    });

    function approve(id){
      //alert('approve '+id);
      $('#schedule_id').val(id);
      $('#modaldemo1').modal('show'); 
      $('#title_modal').html('Are your sure to approve this schedule?');
      $('#form_verification').attr('action', "<?= route('master.schedule.approve') ?>");
    }

    function reject(id){
      //alert('reject '+id);
      $('#schedule_id').val(id);
      $('#modaldemo1').modal('show'); 
      $('#title_modal').html('Are your sure to reject this schedule?');
      $('#form_verification').attr('action', "<?= route('master.schedule.reject') ?>");
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>