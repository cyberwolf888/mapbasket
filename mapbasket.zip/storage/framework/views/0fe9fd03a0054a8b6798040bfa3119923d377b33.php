<?php $__env->startPush('plugin_css'); ?>
    <link href="<?php echo e(url('assets/master')); ?>/lib/datatables/jquery.dataTables.css" rel="stylesheet">
    <link href="<?php echo e(url('assets/master')); ?>/lib/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('master.dashboard')); ?>">Master</a>
        <span class="breadcrumb-item active">Lapangan</span>
        </nav>
    </div><!-- br-pageheader -->

    <div class="br-pagetitle">
        <i class="icon icon ion-ios-book-outline"></i>
        <div>
        <h4>Lapangan</h4>
        <p class="mg-b-0">Manage data lapangan.</p>
        </div>
    </div><!-- d-flex -->

    <div class="br-pagebody">

        <div class="br-section-wrapper">
            <a href="<?php echo e(route('master.lapangan.create')); ?>" class="btn btn-teal btn-with-icon">
              <div class="ht-40">
                <span class="icon wd-40"><i class="fa fa-plus"></i></span>
                <span class="pd-x-15">Create New Data</span>
              </div>
            </a><br><br>
            <div class="table-wrapper">
                    <table id="datatable1" class="table display responsive nowrap">
                            <thead>
                              <tr>
                                <th class="wd-5p">No</th>
                                <th class="wd-40p">Name</th>
                                <th class="wd-45p">Address</th>
                                <th class="wd-10p">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $no = 1; ?>
                              <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($no); ?></td>
                                  <td><?php echo e($item->nama); ?></td>
                                  <td><?php echo e($item->alamat); ?></td>
                                  <td>
                                      <a href="<?php echo e(route('master.lapangan.foto.manage',['id' => $item->id])); ?>" class="btn btn-info btn-icon"><div><i class="fa fa-image"></i></div></a>
                                      <a href="<?php echo e(route('master.lapangan.edit', ['id' => $item->id])); ?>" class="btn btn-warning btn-icon"><div><i class="fa fa-pencil"></i></div></a>
                                      <a href="<?php echo e(route('master.lapangan.show', ['id'=>$item->id])); ?>" class="btn btn-green btn-purple"><div><i class="fa fa-eye"></i></div></a>
                                  </td>
                                  <?php $no++; ?>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
            </div>
        </div>

    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>
    <script src="<?php echo e(url('assets/master')); ?>/lib/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo e(url('assets/master')); ?>/lib/datatables-responsive/dataTables.responsive.js"></script>
    <script src="<?php echo e(url('assets/master')); ?>/lib/select2/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function(){
      'use strict';

      $('#datatable1').DataTable({
        responsive: true,
        language: {
          searchPlaceholder: 'Search...',
          sSearch: '',
          lengthMenu: '_MENU_ items/page',
        }
      });

      // Select2
      $('.dataTables_length select').select2({ minimumResultsForSearch: Infinity });

    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>