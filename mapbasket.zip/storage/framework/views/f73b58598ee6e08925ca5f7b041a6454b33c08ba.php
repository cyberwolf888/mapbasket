<?php $__env->startSection('content'); ?>
<!-- Titlebar
================================================== -->
<div id="titlebar" class="gradient">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
    
                    <h2>Lapangan</h2><span>List Lapangan</span>
    
                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li>Lapangan</li>
                        </ul>
                    </nav>
    
                </div>
            </div>
        </div>
    </div>

<!-- Content
================================================== -->
<div class="container">

	<!-- Blog Posts -->
	<div class="blog-page">
	<div class="row">
		<div class="col-lg-8 col-md-8 padding-right-30">
                
                <!-- Listings Container -->
			<div class="row">

                    <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Listing Item -->
                        <div class="col-lg-12 col-md-12">
                            <div class="listing-item-container list-layout">
                                <a href="<?php echo e(route('detail.lapangan',$item->id)); ?> " class="listing-item">
                                    
                                    <!-- Image -->
                                    <div class="listing-item-image">
                                        <img src="<?php echo e($item->thumb_img); ?>" alt="">
                                        <!-- <span class="tag"><?php echo e($item->nama); ?></span> -->
                                    </div>
                                    
                                    <!-- Content -->
                                    <div class="listing-item-content">
                                        <!-- <div class="listing-badge now-open">Now Open</div> -->
        
                                        <div class="listing-item-inner">
                                            <h3><?php echo e($item->nama); ?></h3>
                                            <span><?php echo e($item->alamat); ?></span>
                                            <div class="star-rating" data-rating="<?php echo e($item->rating); ?>">
                                                <div class="rating-counter">(<?php echo e($item->review()->where('status',1)->count()); ?> reviews)</div>
                                            </div>
                                        </div>
        
                                        <!-- <span class="like-icon"></span> -->
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Listing Item / End -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
    
                </div>
                <!-- Listings Container / End -->


			<!-- Pagination -->
			<div class="clearfix"></div>
			<div class="row">
				<div class="col-md-12">
					<!-- Pagination -->
					<div class="pagination-container margin-bottom-40">
                            <?php echo e($model->links()); ?>

					</div>
				</div>
			</div>
			<!-- Pagination / End -->

		</div>

	<!-- Blog Posts / End -->

    <?php echo $__env->make('frontend.widget', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<!-- Sidebar / End -->


</div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('page_scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>