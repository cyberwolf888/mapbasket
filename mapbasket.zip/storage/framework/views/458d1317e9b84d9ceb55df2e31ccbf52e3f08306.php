<?php $__env->startPush('plugin_css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('master.dashboard')); ?>">Master</a>
        <a class="breadcrumb-item" href="<?php echo e(route('master.lapangan.manage')); ?>">Lapangan</a>
        <span class="breadcrumb-item active">Foto</span>
        </nav>
    </div><!-- br-pageheader -->

    <div class="br-pagetitle">
        <i class="icon icon ion-ios-book-outline"></i>
        <div>
        <h4>Foto Lapangan <?php echo e($lapangan->nama); ?></h4>
        <p class="mg-b-0">Manage foto lapangan.</p>
        </div>
    </div><!-- d-flex -->

    <div class="br-pagebody">

        <div class="br-section-wrapper">
            <a href="<?php echo e(route('master.lapangan.foto.create', ['id'=>$lapangan->id])); ?>" class="btn btn-teal btn-with-icon">
              <div class="ht-40">
                <span class="icon wd-40"><i class="fa fa-plus"></i></span>
                <span class="pd-x-15">Create New Data</span>
              </div>
            </a><br><br>
            <div class="table-wrapper">
                <div class="form-layout form-layout-2">
                    <div class="row no-gutters">
                      <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3" style="margin-right:10px;">
                            <figure class="overlay">
                                <img src="<?php echo e(url('assets/images/lapangan/'.$item->id_lapangan.'/thumb_'.$item->file)); ?>" class="img-fluid" alt="">
                                <figcaption class="overlay-body d-flex align-items-end justify-content-center">
                                  <div class="img-option">
                                    <a href="<?php echo e(route('master.lapangan.foto.delete', $item->id)); ?>" class="img-option-link"><div><i class="icon ion-close"></i></div></a>
                                  </div>
                                </figcaption>
                              </figure>
                              
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function(){
      'use strict';


    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>