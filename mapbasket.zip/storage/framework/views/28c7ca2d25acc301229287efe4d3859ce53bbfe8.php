<nav id="navigation" class="style-1">
    <ul id="responsive">

        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('home.lapangan')); ?>">Lapangan</a></li>
        <li><a href="<?php echo e(route('home.club')); ?>">Club</a></li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-access')): ?>
        <li><a href="<?php echo e(route('master.dashboard')); ?>">Admin</a></li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operator-access')): ?>
        <li><a href="<?php echo e(route('operator.dashboard')); ?>">My Account</a></li>
        <?php endif; ?>
        
    </ul>
</nav>