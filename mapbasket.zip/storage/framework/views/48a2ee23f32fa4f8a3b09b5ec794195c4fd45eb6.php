<?php $__env->startPush('plugin_css'); ?>
    <link href="<?php echo e(url('assets/master')); ?>/lib/datatables/jquery.dataTables.css" rel="stylesheet">
    <link href="<?php echo e(url('assets/master')); ?>/lib/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('operator.dashboard')); ?>">Operator</a>
        <span class="breadcrumb-item active">News</span>
        </nav>
    </div><!-- br-pageheader -->

    <div class="br-pagetitle">
        <i class="icon icon ion-ios-book-outline"></i>
        <div>
        <h4>News</h4>
        <p class="mg-b-0">Manage data News.</p>
        </div>
    </div><!-- d-flex -->

    <div class="br-pagebody">

        <div class="br-section-wrapper">
            <a href="<?php echo e(route('operator.news.create')); ?>" class="btn btn-teal btn-with-icon"> 
              <div class="ht-40">
                <span class="icon wd-40"><i class="fa fa-plus"></i></span>
                <span class="pd-x-15">Create New Data</span>
              </div>
            </a><br><br>

            <div class="table-wrapper">
              <table id="datatable1" class="table display responsive nowrap">
                  <thead>
                    <tr>
                      <th class="wd-5p">No</th>
                      <th class="wd-60p">keterangan</th>
                      <th class="wd-10p">Status</th>
                      <th class="wd-15p">Created At</th>
                      <th class="wd-10p">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($no); ?></td>
                        <td><?php echo e($item->keterangan); ?></td>
                        <td><?php echo e($item->status_text); ?></td>
                        <td><?php echo e(date('d F Y', strtotime($item->created_at))); ?></td>
                        <td>
                            <a href="<?php echo e(route('operator.news.edit', ['id' => $item->id])); ?>" class="btn btn-warning btn-icon"><div><i class="fa fa-pencil"></i></div></a>
                        </td>
                        <?php $no++; ?>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
        </div>

    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>
    <script src="<?php echo e(url('assets/master')); ?>/lib/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo e(url('assets/master')); ?>/lib/datatables-responsive/dataTables.responsive.js"></script>
    <script src="<?php echo e(url('assets/master')); ?>/lib/select2/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function(){
      'use strict';

      $('#datatable1').DataTable({
        responsive: true,
        language: {
          searchPlaceholder: 'Search...',
          sSearch: '',
          lengthMenu: '_MENU_ items/page',
        }
      });

      // Select2
      $('.dataTables_length select').select2({ minimumResultsForSearch: Infinity });

    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.operator', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>