<?php $__env->startSection('content'); ?>
    
<!-- Slider
================================================== -->
<div class="listing-slider mfp-gallery-container margin-bottom-0">
    <?php $__currentLoopData = $model->foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('assets/images/club/'.$foto->id_club.'/'.$foto->file)); ?>" data-background-image="<?php echo e(url('assets/images/club/'.$foto->id_club.'/thumb_'.$foto->file)); ?>" class="item mfp-gallery" title="Title 1"></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<!-- Content
================================================== -->
<div class="container">
	<div class="row sticky-wrapper">
		<div class="col-lg-8 col-md-8 padding-right-30">

			<!-- Titlebar -->
			<div id="titlebar" class="listing-titlebar">
				<div class="listing-titlebar-title">
					<h2><?php echo e($model->nama); ?> </h2>
					<span>
						<a href="#listing-location" class="listing-address">
							<i class="fa fa-map-marker"></i>
							<?php echo e($model->alamat); ?>

						</a>
					</span>
				</div>
			</div>

			<!-- Listing Nav -->
			<div id="listing-nav" class="listing-nav-container">
				<ul class="listing-nav">
					<li><a href="#listing-overview" class="active">Overview</a></li>
					<li><a href="#listing-location">Location</a></li>
					<li><a href="#listing-reviews">News</a></li>
				</ul>
			</div>
			
			<!-- Overview -->
			<div id="listing-overview" class="listing-section">

				<!-- Description -->

				<p>
					<?php echo e($model->keterangan); ?>

				</p>

			</div>
		
			<!-- Location -->
			<div id="listing-location" class="listing-section">
				<h3 class="listing-desc-headline margin-top-60 margin-bottom-30">Location</h3>

				<div id="singleListingMap-container">
                <div id="singleListingMap" data-latitude="<?php echo e($model->lat); ?>" data-longitude="<?php echo e($model->long); ?>" data-map-icon="im im-icon-Football-2"></div>
					<a href="#" id="streetView">Street View</a>
				</div>
			</div>
				
			<!-- Reviews -->
			<div id="listing-reviews" class="listing-section">
				<h3 class="listing-desc-headline margin-top-75 margin-bottom-20">News <span>(<?php echo e($model->news()->where('status',1)->count()); ?>)</span></h3>

				<div class="clearfix"></div>

				<!-- Reviews -->
				<section class="comments listing-reviews">
					<ul>
						<?php
							$news = $model->news()->where('status',1)->orderBy('created_at','desc')->paginate(5);
						?>
						<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li>
								<div class="avatar"><img src="<?php echo e($new->club->thumb_img); ?>" alt="" /> </div>
								<div class="comment-content"><div class="arrow-comment"></div>
									<div class="comment-by"><?php echo e($new->club->nama); ?><span class="date"><?php echo e(date('d F Y', strtotime($new->created_at))); ?> </span>
										
									</div>
									<p><?php echo e($new->keterangan); ?></p>
								</div>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					 </ul>
				</section>

				<!-- Pagination -->
				<div class="clearfix"></div>
				<div class="row">
					<div class="col-md-12">
						<!-- Pagination -->
						<div class="pagination-container margin-top-30">
							<?php echo e($news->links()); ?>

						</div>
					</div>
				</div>
				<div class="clearfix"></div>
				<!-- Pagination / End -->
			</div>
		</div>


		<!-- Sidebar
		================================================== -->
		<div class="col-lg-4 col-md-4 margin-top-75 sticky">

				
		

			<!-- Opening Hours -->
			<div class="boxed-widget opening-hours margin-top-35">
				<div class="listing-badge now-open">Active</div>
				<h3><i class="sl sl-icon-clock"></i> Training Schedule</h3>
				<ul>
                    <?php $__currentLoopData = $model->active_schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($schedule->lapangan->nama); ?> <span><?php echo e(date('D, d M',strtotime($schedule->tgl))); ?>, <?php echo e(date('H:i',strtotime($schedule->start ))); ?> - <?php echo e(date('H:i',strtotime($schedule->end ))); ?></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
				</ul>
			</div>
			<!-- Opening Hours / End -->

			<!-- Share / Like -->
			<div class="listing-share margin-top-40 margin-bottom-40 no-border">
					<!-- Share Buttons -->
					<ul class="share-buttons margin-top-40 margin-bottom-0">
						<li><a class="fb-share" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('detail.club', $model->id)); ?>" target="_blank"><i class="fa fa-facebook"></i> Share</a></li>
						<li><a class="twitter-share" href="https://twitter.com/home?status=<?php echo e(route('detail.club', $model->id)); ?>" target="_blank"><i class="fa fa-twitter"></i> Tweet</a></li>
						<li><a class="gplus-share" href="https://plus.google.com/share?url=<?php echo e(route('detail.club', $model->id)); ?>" target="_blank"><i class="fa fa-google-plus"></i> Share</a></li>
						<!-- <li><a class="pinterest-share" href="#"><i class="fa fa-pinterest-p"></i> Pin</a></li> -->
					</ul>
					<div class="clearfix"></div>
			</div>

		</div>
		<!-- Sidebar / End -->

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>
    <!-- Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_API_KEY')); ?>&amp;libraries=places"></script>
    <script type="text/javascript" src="<?php echo e(url('assets/frontend')); ?>/scripts/infobox.min.js"></script>
    <script type="text/javascript" src="<?php echo e(url('assets/frontend')); ?>/scripts/markerclusterer.js"></script>
    <script type="text/javascript" src="<?php echo e(url('assets/frontend')); ?>/scripts/maps.js"></script>	

<?php $__env->stopPush(); ?>

<?php $__env->startPush('page_scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>