<?php $__env->startPush('plugin_css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('master.dashboard')); ?>">Master</a>
        <a class="breadcrumb-item" href="<?php echo e(route('master.club.manage')); ?>">Club</a>
        <span class="breadcrumb-item active">Foto</span>
        </nav>
    </div><!-- br-pageheader -->

    <div class="br-pagetitle">
        <i class="icon icon ion-ios-book-outline"></i>
        <div>
        <h4>Club</h4>
        <p class="mg-b-0">Create foto club.</p>
        </div>
    </div><!-- d-flex -->

    <div class="br-pagebody">
        <div class="br-section-wrapper">
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="alert alert-danger" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <?php echo e($error); ?>

                    </div><!-- alert -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php echo Form::open(['route' => ['master.club.foto.store', $club->id], 'method' => 'post', 'files'=>true]); ?>

                <div class="form-layout form-layout-1">
                    <div class="row mg-b-25">
                    <div class="col-lg-8">
                        <div class="form-group mg-b-10-force">
                            <label class="custom-file">
                            <input type="file" name="image" id="image" class="custom-file-input" accept="image/*">
                            <span class="custom-file-control"></span>
                            </label>
                        </div>
                    </div><!-- col-8 -->
                    </div><!-- row -->
        
                    <div class="form-layout-footer">
                    <button class="btn btn-info" type="submit">Save Data</button>
                    <a class="btn btn-secondary" href="<?php echo e(route('master.club.foto.manage', ['id'=>$club->id])); ?>">Cancel</a>
                    </div><!-- form-layout-footer -->
                </div><!-- form-layout -->
                <?php echo Form::close(); ?>

        </div>

    </div><!-- br-pagebody -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin_scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>